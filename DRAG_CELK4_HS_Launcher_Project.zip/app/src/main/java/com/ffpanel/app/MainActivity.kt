package com.ffpanel.app

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Black = Color(0xFF000000)
private val White = Color(0xFFF4F4F4)
private val Grey = Color(0xFF929292)
private val FreeFirePackage = "com.dts.freefireth"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Black, surface = Black, primary = Color(0xFF168BFF)
            )) {
                LauncherScreen(
                    onCheckGame = { checkFreeFireInstalled() },
                    onLaunchGame = { launchFreeFire() },
                    onOpenPanel = { openPanelPreview() }
                )
            }
        }
    }

    private fun checkFreeFireInstalled(): Boolean {
        val installed = try {
            packageManager.getPackageInfo(FreeFirePackage, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
        Toast.makeText(
            this,
            if (installed) "Free Fire terdeteksi" else "Free Fire TH belum terpasang",
            Toast.LENGTH_SHORT
        ).show()
        return installed
    }

    private fun launchFreeFire() {
        val launchIntent = packageManager.getLaunchIntentForPackage(FreeFirePackage)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "Free Fire TH tidak ditemukan di perangkat", Toast.LENGTH_LONG).show()
        }
    }

    private fun openPanelPreview() {
        startActivity(Intent(this, PanelPreviewActivity::class.java))
    }
}

@Composable
private fun LauncherScreen(
    onCheckGame: () -> Boolean,
    onLaunchGame: () -> Unit,
    onOpenPanel: () -> Unit
) {
    var gameDetected by remember { mutableStateOf<Boolean?>(null) }

    Column(
        Modifier.fillMaxSize().background(Black).padding(horizontal = 34.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(46.dp))
        Image(
            painter = painterResource(R.drawable.kaf_logo),
            contentDescription = "KAF Kakoro Apeka Files logo",
            modifier = Modifier.size(154.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.height(18.dp))
        Text(
            "DRAG CELK4/HS",
            color = White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.5.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(76.dp))
        Text(
            when (gameDetected) {
                true -> "Free Fire terdeteksi"
                false -> "Free Fire tidak ditemukan"
                null -> "Siap"
            },
            color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().padding(start = 4.dp)
        )
        Spacer(Modifier.height(70.dp))
        LauncherButton("FREE FIRE", enabled = true, onClick = {
            gameDetected = onCheckGame()
        })
        Spacer(Modifier.height(16.dp))
        LauncherButton("CONNECT", enabled = true, onClick = {
            gameDetected = onCheckGame()
        }, filled = true)
        Spacer(Modifier.height(16.dp))
        LauncherButton("DISCONNECT", enabled = true, onClick = {
            gameDetected = null
        })
        Spacer(Modifier.height(16.dp))
        LauncherButton("LAUNCH GAME", enabled = true, onClick = onLaunchGame)
        Spacer(Modifier.weight(1f))
        TextButton(onClick = onOpenPanel) {
            Text("OPEN DRAG CELK4/HS PANEL", color = Color(0xFF4DA6FF), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun LauncherButton(
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
    filled: Boolean = false
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(66.dp),
        shape = RoundedCornerShape(17.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (filled) Color(0xFF4C4C4C) else Color(0xFF999999),
            contentColor = Color.Black,
            disabledContainerColor = Color(0xFF4C4C4C),
            disabledContentColor = Color(0xFF777777)
        )
    ) {
        Text(label, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

class PanelPreviewActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Black, surface = Color(0xFF10131C))) {
                Column(
                    Modifier.fillMaxSize().background(Black).padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Image(
                        painter = painterResource(R.drawable.kaf_logo),
                        contentDescription = "KAF logo",
                        modifier = Modifier.size(120.dp)
                    )
                    Spacer(Modifier.height(16.dp))
                    Text("DRAG CELK4/HS", color = White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("80%", color = Color(0xFF168BFF), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(18.dp))
                    Text(
                        "Panel tampilan lokal",
                        color = Grey,
                        modifier = Modifier.border(1.dp, Color(0xFF343A49), RoundedCornerShape(10.dp)).padding(16.dp)
                    )
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = { finish() }) { Text("BACK") }
                }
            }
        }
    }
}
